# Final Project Group 10

1. Run the  goBang_main.py to run the program
2. Input the 1,2,3 to choose game mode